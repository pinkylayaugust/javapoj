package action;

import org.apache.struts.action.ActionForm;

public class adminform extends ActionForm {	
	String txtemail;
	String txtpsw;
	public String getTxtemail() {
		return txtemail;
	}
	public void setTxtemail(String txtemail) {
		this.txtemail = txtemail;
	}
	public String getTxtpsw() {
		return txtpsw;
	}
	public void setTxtpsw(String txtpsw) {
		this.txtpsw = txtpsw;
	}
	
	
}
