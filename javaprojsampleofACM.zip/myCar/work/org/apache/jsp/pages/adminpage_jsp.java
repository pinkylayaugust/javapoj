package org.apache.jsp.pages;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public final class adminpage_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title>Car Information</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body text=\"blue\">\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/myCar/pages/style.css\"/>\r\n");
      out.write(" <div id=\"wrapper\">\r\n");
      out.write(" <div class=\"header\"><img src=\"/myCar/image/barbie.jpg\" >&nbsp;&nbsp;<img src=\"/myCar/image/barbie.jpg\" >&nbsp;&nbsp;<img src=\"/myCar/image/pbarbie.jpg\" ></div><div class=\"clear\"></div>\r\n");
      out.write(" <div class=\"menu\"><a href=\"/myCar/pages/Welcome.jsp\">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/aboutus.jsp\">About</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/contactus.jsp\">Contact Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/Welcome.jsp\">Logout</a></div>\r\n");
      out.write("<div class=\"body\">\r\n");
      out.write("\r\n");
      out.write("\r\n");

String adminemail=request.getParameter("txtemail");
System.out.println("Admin Email is"+adminemail);
String adminpsw=request.getParameter("txtpsw");
System.out.println("Admin Password is"+adminpsw);
String url="jdbc:mysql://localhost/carproject?user=root&password=root"; 
Statement stmt=null;
  try{
	  Class.forName("com.mysql.jdbc.Driver"); 
   Connection con=(Connection) DriverManager.getConnection(url);
   stmt=(Statement) ((java.sql.Connection) con).createStatement();        
   String strcar="SELECT *  FROM car INNER JOIN model ON car.model_id=model.model_id";
   ResultSet up=stmt.executeQuery(strcar);
   System.out.println("DB car connection succeed");
   out.println("<table border=1 width='660px' height='600px' style='overflow-x:scroll'>");
   out.println("<tr>");
   out.println("<th>License_no</th>");
   out.println("<th>Color</th>");
   out.println("<th>Kilometers</th>");
   out.println("<th>Price</th>");
   //out.println("<th>Engine_type</th>");
   out.println("<th>Engine_Power</th>");
   out.println("<th>Car_brand</th>");
   //out.println("<th>Fuel_type</th>");
   //out.println("<th>Warranty</th>");
   out.println("<th>Image</th>");
   //out.println("<th>Front_view_pic</th>");
   //out.println("<th>Side_view_pic</th>");
   //out.println("<th>Back_view_pic</th>");
   //out.println("<th>Seat</th>");
   //out.println("<th>Door</th>");
   out.println("<th>Body_type</th>");
   //out.println("<th>Model</th>");
   out.println("<th>Edit</th>");
   out.println("<th>Delete</th>");
   out.println("</tr>");
   
   while (up.next()) 
   {  
	   String lic_no=up.getString(1);
	   String color=up.getString(2);
	   Integer kilo=up.getInt(3);
	   Double price=up.getDouble(4);
	   //String engtype=up.getString(5);
	   String engpow=up.getString(6);
	   String carBrand=up.getString(7);
	   //String fuelty=up.getString(8);
	   //Integer war=up.getInt(9);
	   String mainpic=up.getString(10);
	   //String frontpic=up.getString(11);
	   //String sidepic=up.getString(12);
	   //String backpic=up.getString(13);
	   //Integer seat=up.getInt(14);
	   //Integer door=up.getInt(15);
	   String bodytype=up.getString(13);
	   int modnum=up.getInt(16);
	   out.println("<tr>");	  
	   out.println("<td>"+lic_no+"</td>");
	   out.println("<td>"+color+"</td>");
	   out.println("<td>"+kilo+"</td>");
	   out.println("<td>"+price+"</td>");
	   //out.println("<td>"+engtype+"</td>");
	   out.println("<td>"+engpow+"</td>");
	   out.println("<td>"+carBrand+"</td>");
	  // out.println("<td>"+fuelty+"</td>");
	   //out.println("<td>"+war+"</td>");	
	   out.println("<td><img src=/myCar/image/"+mainpic+" width=70px height=70px></td>");
	  // out.println("<td><img src=/myCar/image/"+frontpic+" width=70px height=70px></td>");
	   //out.println("<td><img src=/myCar/image/"+sidepic+" width=70px height=70px></td>");
	   //out.println("<td><img src=/myCar/image/"+backpic+" width=70px height=70px></td>");
	   //out.println("<td>"+seat+"</td>");
	   //out.println("<td>"+door+"</td>");
	   out.println("<td>"+bodytype+"</td>");
	  // out.println("<td>"+modnum+"</td>");	
	   out.println("<td><a style='text-align:right top;' href='/myCar/jsp/updateoperation.jsp?id="+lic_no+"'><img src='/myCar/image/edit.jpg' width=30px height=30px></a></td>");
	   out.println("<td><a style='text-align:right top;' href='/myCar/pages/delete.jsp?id="+lic_no+"'><img src='/myCar/image/delete.jpg' width=30px height=30px></a></td>");
	   
	   out.println("</tr>");
	  
   }
   out.println("</table>");
  }
  catch(Exception ex){
	   ex.printStackTrace();
	   }
  
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("<form action=\"/myCar/jsp/insert.jsp\" method=\"post\">\r\n");
      out.write("<input type=\"submit\" value=\"Insert Car\">\r\n");
      out.write("</form>\r\n");
      out.write("<form action=\"/myCar/jsp/insertmodel.jsp\" method=\"post\">\r\n");
      out.write("<input type=\"submit\" value=\"Insert Model\">\r\n");
      out.write("</form>\r\n");
      out.write("  </div>\t  \r\n");
      out.write("\t\t\t \r\n");
      out.write("              <div class=\"footer\"><center><b><i>Developed by MA AYE CHAN MON</i></b></center></div>\r\n");
      out.write("              </div>\r\n");
      out.write("\t\t </div>  \r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
