package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public final class cardetail_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title>Car Information</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body text=\"blue\">\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/myCar/pages/style.css\"/>\r\n");
      out.write(" <div id=\"wrapper\">\r\n");
      out.write(" <div class=\"header\"><img src=\"/myCar/image/barbie.jpg\" >&nbsp;&nbsp;<img src=\"/myCar/image/barbie.jpg\" >&nbsp;&nbsp;<img src=\"/myCar/image/pbarbie.jpg\" ></div><div class=\"clear\"></div>\r\n");
      out.write(" <div class=\"menu\"><a href=\"/myCar/pages/Welcome.jsp\">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/aboutus.jsp\">About</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/contactus.jsp\">Contact Us</a></div>\r\n");
      out.write("<div class=\"body\"><br><br><br>\r\n");
      out.write("\r\n");

String licenseno=request.getParameter("lic");
System.out.println("License NO is"+licenseno);
String url="jdbc:mysql://localhost/carproject?user=root&password=root"; 
Statement stmt=null;
  try{
	  Class.forName("com.mysql.jdbc.Driver"); 
   Connection con=(Connection) DriverManager.getConnection(url);
   stmt=(Statement) ((java.sql.Connection) con).createStatement(); 
   String strbrand="SELECT * FROM car INNER JOIN model ON car.model_id=model.model_id where license_no='"+licenseno+"'"; 
   ResultSet rs=stmt.executeQuery(strbrand); 
   System.out.println("DB connection succeed");
   while (rs.next()) 
   {
	   
	   String mainpic=rs.getString(10);	  
	   String lic_no=rs.getString(1); 
	   long price=rs.getLong(4);
	   
	   String color=rs.getString(2);
	   Integer kilo=rs.getInt(3);
	   String engtype=rs.getString(5);
	   String engpow=rs.getString(6);
	   String carBrand=rs.getString(7);
	   String fuelty=rs.getString(8);
	   Integer war=rs.getInt(9);
	   int modnum=rs.getInt(16);
	   Integer seat=rs.getInt(11);
	   Integer door=rs.getInt(12);
	   String bodytype=rs.getString(13);
	   
      out.write("\r\n");
      out.write("\t    <table>\r\n");
      out.write("\t     \r\n");
      out.write("        <img src='../image/");
      out.print(mainpic );
      out.write("' width=\"250px\" height=\"200px\">              \r\n");
      out.write("\t    <tr><td>License no:</td><td>");
      out.print(lic_no);
      out.write("</td></tr>\r\n");
      out.write("\t    <tr><td>Price:</td><td>");
      out.print(price );
      out.write("</td></tr>\r\n");
      out.write("\t    <tr><td>Color:</td><td>");
      out.print(color );
      out.write("</td></tr>\r\n");
      out.write("\t    <tr><td>Kilometer</td><td>");
      out.print(kilo );
      out.write("</td></tr>\r\n");
      out.write("\t    <tr><td>Engine Type</td><td>");
      out.print(engtype );
      out.write("</td></tr>\r\n");
      out.write("\t    <tr><td>Engine Power</td><td>");
      out.print(engpow );
      out.write("</td></tr>\r\n");
      out.write("\t     <tr><td>Car Brand</td><td>");
      out.print(carBrand );
      out.write("</td></tr>\r\n");
      out.write("\t      <tr><td>Fuel Type</td><td>");
      out.print(fuelty );
      out.write("</td></tr>\r\n");
      out.write("\t      <tr><td>Model Number:</td><td>");
      out.print(modnum );
      out.write("</td></tr>\r\n");
      out.write("\t       <tr><td>Warranty</td><td>");
      out.print(war );
      out.write("</td></tr>\r\n");
      out.write("\t        <tr><td>Seat</td><td>");
      out.print(seat );
      out.write("</td></tr>\r\n");
      out.write("\t         <tr><td>Door</td><td>");
      out.print(door );
      out.write("</td></tr>\r\n");
      out.write("\t          <tr><td>Body Type</td><td>");
      out.print(bodytype );
      out.write("</td></tr>\r\n");
      out.write("\t     \r\n");
      out.write("\t        ");
 out.println("<tr><td colspan=2><a style='text-align:right top;' href='UserLoginValidation.jsp?id="+lic_no+"&pric="+price+"'><img src='../image/buyp.jpg' width='150px' height='50px'></a></td></tr>");
	        
      out.write("\r\n");
      out.write("\t    </table>\r\n");
      out.write("\t    ");

   }
  }
  catch(Exception ex){
	   ex.printStackTrace();
	   }

      out.write("\r\n");
      out.write("<br><br>\r\n");
      out.write("               </div>\t  \r\n");
      out.write("\t\t\t \r\n");
      out.write("              <div class=\"footer\"><center><b><i>Developed by MA AYE CHAN MON</i></b></center></div>\r\n");
      out.write("              </div>\r\n");
      out.write("\t\t </div> \r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
