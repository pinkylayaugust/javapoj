package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class updateoperation_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Insert title here</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"../pages/style.css\"/>\r\n");
      out.write(" <link rel=\"stylesheet\" type=\"text/css\" href=\"/myCar/pages/style.css\"/>\r\n");
      out.write(" <div id=\"wrapper\">\r\n");
      out.write(" <div class=\"header\"><img src=\"/myCar/image/barbie.jpg\" >&nbsp;&nbsp;<img src=\"/myCar/image/barbie.jpg\" >&nbsp;&nbsp;<img src=\"/myCar/image/pbarbie.jpg\" ></div><div class=\"clear\"></div>\r\n");
      out.write(" <div class=\"menu\"><a href=\"/myCar/pages/Welcome.jsp\">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/aboutus.jsp\">About</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/contactus.jsp\">Contact Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/Welcome.jsp\">Logout</a></div>\r\n");
      out.write("<div class=\"body\">\r\n");
      out.write("\r\n");
      out.write("\r\n");

String licenseno=request.getParameter("id");
System.out.println("License NO is"+licenseno);

      out.write("\r\n");
      out.write("<form method=\"get\" action=\"updateprocess.jsp\">\r\n");
      out.write("<table border=1 width=\"40%\" height=\"80%\" align=\"center\">\r\n");
      out.write("      <caption><u>Employee Update Form</u></caption>\r\n");
      out.write("      <tr>\r\n");
      out.write("            <td></\r\n");
      out.write("              <table border=1 color=pink>\r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>License No</td>\r\n");
      out.write("                 <td>:<input name=\"Licno\" type=\"text\" value=");
      out.print(licenseno );
      out.write(">\r\n");
      out.write("              </tr>            \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Color</td>\r\n");
      out.write("                 <td>:<input name=\"color\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Kilometer</td>\r\n");
      out.write("                 <td>:<input name=\"kilo\" type=\"text\">\r\n");
      out.write("              </tr>  \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Price</td>\r\n");
      out.write("                 <td>:<input name=\"pri\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Engine Type</td>\r\n");
      out.write("                 <td>:<input name=\"eng\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Engine Power</td>\r\n");
      out.write("                 <td>:<input name=\"engpow\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Car Brand</td>\r\n");
      out.write("                 <td>:<input name=\"cb\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Fuel type</td>\r\n");
      out.write("                 <td>:<input name=\"fu\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Warranty</td>\r\n");
      out.write("                 <td>:<input name=\"wty\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Seat</td>\r\n");
      out.write("                 <td>:<input name=\"st\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("              <tr>\r\n");
      out.write("                 <td>Door</td>\r\n");
      out.write("                 <td>:<input name=\"dor\" type=\"text\">\r\n");
      out.write("              </tr> \r\n");
      out.write("               <tr>\r\n");
      out.write("                 <td>Body Type</td>\r\n");
      out.write("                 <td>:<input name=\"bdy\" type=\"text\">\r\n");
      out.write("              </tr>     \r\n");
      out.write("              <tr>\r\n");
      out.write("              <td colspan=2 align=center>\r\n");
      out.write("                  <input type=\"submit\" value=\"Update\">&nbsp;&nbsp;&nbsp;\r\n");
      out.write("                  <input type=\"reset\" value=\"Cancel\">\r\n");
      out.write("              </table>\r\n");
      out.write("            </td>\r\n");
      out.write("      </tr>\r\n");
      out.write("      </table>\r\n");
      out.write("      </form>\r\n");
      out.write("      </div>\t  \r\n");
      out.write("\t\t\t \r\n");
      out.write("              <div class=\"footer\"><center><b><i>Developed by MA AYE CHAN MON</i></b></center></div>\r\n");
      out.write("              </div>\r\n");
      out.write("\t\t </div> \r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
