package org.apache.jsp.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public final class result_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title>Car Information</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body text=\"blue\">\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"/myCar/pages/style.css\"/>\r\n");
      out.write(" <div id=\"wrapper\">\r\n");
      out.write(" <div class=\"header\"><img src=\"/myCar/image/barbie.jpg\" >&nbsp;&nbsp;<img src=\"/myCar/image/barbie.jpg\" >&nbsp;&nbsp;<img src=\"/myCar/image/pbarbie.jpg\" ></div><div class=\"clear\"></div>\r\n");
      out.write(" <div class=\"menu\"><a href=\"/myCar/pages/Welcome.jsp\">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/aboutus.jsp\">About</a>&nbsp;&nbsp;|&nbsp;&nbsp;\r\n");
      out.write("    <a href=\"/myCar/pages/contactus.jsp\">Contact Us</a></div>\r\n");
      out.write("<div class=\"body\">\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");



String url="jdbc:mysql://localhost/carproject?user=root&password=root"; 
Statement stmt=null;
  try{
	  Class.forName("com.mysql.jdbc.Driver"); 
   Connection con=(Connection) DriverManager.getConnection(url);
   stmt=(Statement) ((java.sql.Connection) con).createStatement();
	 String price=(String)pageContext.getAttribute("Price", PageContext.SESSION_SCOPE);
   System.out.println("String User Price in Result is "+price);
   long pric=Long.parseLong(price);
   System.out.println("Parse User PricInt "+pric);
   
   
   String uname=request.getParameter("name").toString();
   String uemail=request.getParameter("email").toString();   
   String ugen=request.getParameter("gender").toString();
   String ucity=request.getParameter("city").toString();
   String upno=request.getParameter("pno").toString();
   String uatmno=request.getParameter("atmno").toString();
   System.out.println("Form Success");   
   String struser="INSERT INTO user(username,email,gender,city,phoneno) VALUES ('"+uname+"','"+uemail+"','"+ugen+"','"+ucity+"','"+upno+"')";
   int RowCount=stmt.executeUpdate(struser);   
   System.out.println("Insert User Login Success");   
   
   String stratm="SELECT * FROM atmcard where atmno='"+uatmno+"'"; 
   ResultSet rs=stmt.executeQuery(stratm);  
   
   while (rs.next()) 
      {
	     System.out.println("IN WHILE ");
	     String useratm=rs.getString(2);
	     System.out.println("User ATM Number is"+useratm);
	     double useramount=rs.getDouble(3);
	     System.out.println("User Amount is"+useramount); 
	     if(uatmno.equals(useratm))
	     {
	          
	    if(useramount>=pric){
	    	useramount=useramount-pric;
	    	 String strmyamount="update atmcard set amount='"+useramount+"' where atmno='"+useratm+"'";
	    	  int rowCount=stmt.executeUpdate(strmyamount);   
	    	   System.out.println("Update Amount Success");
	    	   out.println("<center><img src='/myCar/image/wee.jpg'></center><br><br>");
	    	   out.println("Welcome "+uname);
	    	   out.println("<br>Price is "+pric);
	    	   out.println("<br>Thank you for buying cars in my Website");
	    }
	    else
	    {
	    out.println("Your money in ATMno is not enough");
	    }
	     }
	     else
	     {
	    	 System.out.println("Your Credit Card Number is not valid");
	     }

      }  
  
   
 
  
   
  }
  catch(Exception ex){
	   ex.printStackTrace();
	   }
  
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("</div>\t  \r\n");
      out.write("\t\t\t \r\n");
      out.write("              <div class=\"footer\"><center><b><i>Developed by MA AYE CHAN MON</i></b></center></div>\r\n");
      out.write("              </div>\r\n");
      out.write("\t\t </div> \r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
